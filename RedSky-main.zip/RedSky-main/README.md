<h1 align="center">RedSky</h1>

# What is RedSky?
RedSky is a database menagament tool that you can use on Windows OS, Mac OS and, Linux OS.

<img src="Screenshot (419).png">

# Why RedSky?
* RedSky is for free.
* Will never track your information. 
* Will be updated.
* Bug fixes regularly.
* Will not save any of your information so there is no risk of leak.

# Development Process
It took me 3-4 days to develop the software. The problems I ran in to were SQL connection but I was able to fix problem without wasting a lot of time on it. I had to learn SQL to create/delete databases/tables but using the w3schools resources online was very helpful and I learned enought SQL to finish my software.I developed this software on the console because I wanted everyone to use it.

# What were the challanges?
* I took an error message while I was connecting to my Database on cPanel. (Took me 3-4 hours to figure out).
  * Solved the problem and wrote a Medium Page about it. 
  * Medium Page: https://medium.com/@simpleapps007/cpanel-mysql-error-how-to-fix-it-fee2f7aa47c0
